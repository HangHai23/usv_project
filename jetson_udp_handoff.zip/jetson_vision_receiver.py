"""Reference receiver, Python standard library only. Prints data; NEVER drives motors."""
import argparse
import json
import math
import socket
import time


class ReceiverState:
    def __init__(self):
        self.session=None;self.retired=set();self.seq=-1;self.coord=None
        self.latest=None;self.deadline=0

    def accept(self, data, now):
        if len(data)>1400:return False
        try:
            p=json.loads(data,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
            if not isinstance(p,dict) or p.get('protocol')!='air2s.vision' or p.get('version')!=1:return False
            session=p['session'];seq=p['seq'];ttl=p['ttl_ms'];age=p['age_ms']
            if not isinstance(session,str) or len(session)!=32:return False
            if type(seq)!=int or seq<0 or type(ttl)!=int or not 100<=ttl<=2000:return False
            if session in self.retired:return False
            fresh=p['fresh'];obs=p['observation']
            if type(fresh)!=bool:return False
            if fresh:
                if not isinstance(age,(int,float)) or not 0<=age<ttl:return False
                if not isinstance(obs,dict) or not isinstance(obs.get('coord'),str):return False
                if type(obs.get('field_valid'))!=bool or not isinstance(obs.get('boats'),list):return False
                if not isinstance(obs.get('ball'),dict) or not isinstance(obs.get('goals'),list):return False
                def point(v):
                    return v is None or (isinstance(v,list) and len(v)==2 and
                        all(type(x) in (int,float) and math.isfinite(x) for x in v))
                if not point(obs['ball'].get('xy_m')):return False
                if obs['ball'].get('state') not in ('detected','predicted','lost'):return False
                if obs['ball']['state']!='detected' and obs['ball'].get('xy_m') is not None:return False
                if type(obs.get('frame'))!=int or obs['frame']<1:return False
                if not point(obs.get('size_m')):return False
                for boat in obs['boats']:
                    if type(boat.get('id'))!=int or not point(boat.get('xy_m')):return False
                    heading=boat.get('tag_heading_deg')
                    if heading is not None and (type(heading) not in (int,float) or not math.isfinite(heading) or not -180<=heading<=180):return False
                    if boat.get('possession') not in ('held','candidate','free','unknown'):return False
                for goal in obs['goals']:
                    if goal.get('side') not in ('left','right'):return False
                    ends=goal.get('ends_m')
                    if not isinstance(ends,list) or len(ends)!=2 or not all(v is not None and point(v) for v in ends):return False
            elif obs is not None:return False
        except (ValueError,KeyError,TypeError,UnicodeError,AttributeError):return False
        if session!=self.session:
            if self.session:self.retired.add(self.session)
            self.session=session;self.seq=-1;self.latest=None;self.coord=None
        if seq<=self.seq:return False
        self.seq=seq
        self.latest=None
        if fresh:
            self.coord=obs['coord']
            self.deadline=now+min(.5,(ttl-age)/1000)
            if obs['field_valid']:self.latest=obs
        return True

    def current(self,now):
        if now>=self.deadline:self.latest=None
        return self.latest


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bind',default='0.0.0.0');parser.add_argument('--port',type=int,default=5700)
    parser.add_argument('--mac-ip',required=True,help='Only accept this source IPv4 address')
    args=parser.parse_args();state=ReceiverState()
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
        sock.bind((args.bind,args.port));sock.settimeout(.1)
        while True:
            try:
                data,peer=sock.recvfrom(65535)
                if peer[0]!=args.mac_ip:continue
                if state.accept(data,time.monotonic()):
                    print(json.dumps(state.current(time.monotonic()),ensure_ascii=False),flush=True)
            except socket.timeout:
                if state.current(time.monotonic()) is None:print('STALE / INVALID: no navigation observation',flush=True)

if __name__=='__main__':main()
